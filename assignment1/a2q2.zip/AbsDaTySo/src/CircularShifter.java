import java.util.ArrayList;
import java.util.ListIterator;
import java.util.StringTokenizer;


public class CircularShifter {
	private ArrayList<String> textLines;
	private int shiftedLineIndexes;
	public CircularShifter(){
		textLines=new ArrayList<String>();
		shiftedLineIndexes=0;
	}
	public void execute(String inputLine){
		StringTokenizer tokener = new StringTokenizer(inputLine);
		String token = new String();
		ArrayList<String> tokens = new ArrayList<String>();
        int count = tokener.countTokens();
        for (int j = 0; j < count; j++) {
            token = tokener.nextToken();
            tokens.add(token);
        }
        for (int i = 0; i < count; i++) {
        	shiftedLineIndexes=i;
            StringBuffer linebuffer = new StringBuffer();
            for (int j = 0; j < count; j++) {
                if (shiftedLineIndexes >= count)
                	shiftedLineIndexes = 0;
                    linebuffer.append ( tokens.get(shiftedLineIndexes));
                    linebuffer.append (" ");
                    shiftedLineIndexes++;
            }
            textLines.add(linebuffer.toString());
        }
	}
	public ListIterator<String> getListIterator(){
		return textLines.listIterator();
	}
}
