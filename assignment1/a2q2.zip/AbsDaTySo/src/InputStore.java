import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;


public class InputStore {
	private String fileName;
	private ArrayList<String> textLines;
	public InputStore(String filename){
		fileName=filename;
		textLines=new ArrayList<String>();
	}
	public void execute(){
		String line="";
		try {
			BufferedReader bf=new BufferedReader(new FileReader(fileName));
			while(line!=null){
				try {
					line=bf.readLine();
					if(line!=null)
						textLines.add(line);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			bf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public ListIterator<String> getListIterator(){
		return textLines.listIterator();
	}
}
