import java.util.ListIterator;


public class MainPro {
	public static void main(String [] args){
		String inputFile="input.txt";
		InputStore is = new InputStore(inputFile);;
		CircularShifter cs=new CircularShifter();
		Alphabetizer ab=new Alphabetizer();
		Outputer op=new Outputer();
		is.execute();
		ListIterator<String> li=is.getListIterator();
		while(li.hasNext()){
			cs.execute(li.next());
		}
		li=cs.getListIterator();
		while(li.hasNext()){
			ab.execute(li.next());
		}
		li=ab.getListIterator();
		while(li.hasNext()){
			op.execute(li.next());
		}
	}
}
