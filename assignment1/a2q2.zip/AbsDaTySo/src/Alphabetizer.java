import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;


public class Alphabetizer {
	private ArrayList<String> textLines;
	
	public Alphabetizer(){
		textLines=new ArrayList<String>();
	}
	public void execute(String inputLine){
		textLines.add(inputLine);
		Collections.sort(textLines);
	}
	public ListIterator<String> getListIterator(){
		return textLines.listIterator();
	}
}
