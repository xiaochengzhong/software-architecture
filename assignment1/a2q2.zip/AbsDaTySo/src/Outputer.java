import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Outputer {
	private ArrayList<String> textLines;
	private static final String output_filename="output.txt";
	public Outputer(){
		textLines=new ArrayList<String>();
	}
	public void execute(String inputLine){
		textLines.add(inputLine);
		BufferedWriter bw=null;
		try {
			bw=new BufferedWriter(new FileWriter(output_filename));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i!=textLines.size();i++){
			try {
				bw.write(textLines.get(i));
				bw.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
