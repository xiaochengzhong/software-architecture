import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class kwic {
	private static ArrayList<String> textLines;
	private static int shiftedLineIndexes,sortedLineIndexes;
	private String fileName;
	private static final String output_filename="output.txt";
	public kwic(String filename){
		textLines=new ArrayList<String>();
		shiftedLineIndexes=0;
		setSortedLineIndexes(0);
		fileName=filename;
	}
	private static ArrayList<String> input(String file_name){
		ArrayList<String> inputList=new ArrayList<String>();
		String line="";
		try {
			BufferedReader bf=new BufferedReader(new FileReader(file_name));
			while(line!=null){
				try {
					line=bf.readLine();
					if(line!=null)
						inputList.add(line);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inputList;
	}
	private static void circularShift(String inputLine){
		StringTokenizer tokener = new StringTokenizer(inputLine);
		String token = new String();
		ArrayList<String> tokens = new ArrayList<String>();
        int count = tokener.countTokens();
        for (int j = 0; j < count; j++) {
            token = tokener.nextToken();
            tokens.add(token);
        }
        for (int i = 0; i < count; i++) {
        	shiftedLineIndexes=i;
            StringBuffer linebuffer = new StringBuffer();
            for (int j = 0; j < count; j++) {
                if (shiftedLineIndexes >= count)
                	shiftedLineIndexes = 0;
                    linebuffer.append ( tokens.get(shiftedLineIndexes));
                    linebuffer.append (" ");
                    shiftedLineIndexes++;
            }
            textLines.add(linebuffer.toString());
        }
	}
	private static void alphabetizer(){
		Collections.sort(textLines);
	}
	private static void output(){
		BufferedWriter bw=null;
		try {
			bw=new BufferedWriter(new FileWriter(output_filename));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i!=textLines.size();i++){
			try {
				bw.write(textLines.get(i));
				bw.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	public void execute(){
		ArrayList<String> inputList=input(fileName);
		for(int i=0;i!=inputList.size();i++){
			circularShift(inputList.get(i));
		}
		alphabetizer();
		output();
	}
	public static void main(String[] args){
		new kwic("input.txt").execute();
	}
	public static void setSortedLineIndexes(int sortedLineIndexes) {
		kwic.sortedLineIndexes = sortedLineIndexes;
	}
	public static int getSortedLineIndexes() {
		return sortedLineIndexes;
	}
}
