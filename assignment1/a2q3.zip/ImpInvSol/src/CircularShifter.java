import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.StringTokenizer;


public class CircularShifter implements Observer {
	private int shiftedLineIndexes;
	private EventManager em;

	public CircularShifter(EventManager e){
		shiftedLineIndexes=0;
		em=e;
	}
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		String cmd=(String) arg;
		if(cmd.equals("one")){
			StringTokenizer tokener = new StringTokenizer(Data.TextLine);
			String token = new String();
			ArrayList<String> tokens = new ArrayList<String>();
	        int count = tokener.countTokens();
	        for (int j = 0; j < count; j++) {
	            token = tokener.nextToken();
	            tokens.add(token);
	        }
	        for (int i = 0; i < count; i++) {
	        	shiftedLineIndexes=i;
	            StringBuffer linebuffer = new StringBuffer();
	            for (int j = 0; j < count; j++) {
	                if (shiftedLineIndexes >= count)
	                	shiftedLineIndexes = 0;
	                    linebuffer.append ( tokens.get(shiftedLineIndexes));
	                    linebuffer.append (" ");
	                    shiftedLineIndexes++;
	            }
	            Data.TextLines.add(linebuffer.toString());
	        }
	        em.sendEvent("two");
		}
	}

}
