
public class MainPro {
	
	public static void main(String[] args){
		String inputFile="input.txt";
		EventManager em=new EventManager();
		new Data();
		Inputer ip = new Inputer(inputFile, em);;
		CircularShifter cs=new CircularShifter(em);
		Alphabetizer ab=new Alphabetizer();
		Outputer op=new Outputer();
		em.addListener(cs);
		em.addListener(ab);
		ip.execute();
		op.execute();
	}
}
