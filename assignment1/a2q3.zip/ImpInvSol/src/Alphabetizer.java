import java.util.Collections;
import java.util.Observable;
import java.util.Observer;


public class Alphabetizer implements Observer {

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		String cmd=(String) arg;
		if(cmd.equals("two")){
			Collections.sort(Data.TextLines);
		}
	}

}
