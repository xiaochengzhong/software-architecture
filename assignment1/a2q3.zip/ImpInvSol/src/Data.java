import java.util.ArrayList;


public class Data {
	public static String TextLine ;
	public static ArrayList<String> TextLines;
	public Data(){
		TextLine="";
		TextLines=new ArrayList<String>();
	}
}
