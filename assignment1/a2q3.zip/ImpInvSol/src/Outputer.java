import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class Outputer {
	private static final String output_filename="output.txt";
	public void execute(){
		BufferedWriter bw=null;
		try {
			bw=new BufferedWriter(new FileWriter(output_filename));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=0;i!=Data.TextLines.size();i++){
			try {
				bw.write(Data.TextLines.get(i));
				bw.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
