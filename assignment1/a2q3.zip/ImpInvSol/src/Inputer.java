import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Inputer {
	private String fileName;
	private EventManager em;
	public Inputer(String filename, EventManager e){
		fileName=filename;
		em=e;
	}
	public void execute(){
		String line="";
		try {
			BufferedReader bf=new BufferedReader(new FileReader(fileName));
			while(line!=null){
				try {
					line=bf.readLine();
					if(line!=null){
						Data.TextLine=line;
						em.sendEvent("one");
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			bf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
