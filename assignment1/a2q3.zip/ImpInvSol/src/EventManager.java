import java.util.Observable;
import java.util.Observer;


public class EventManager extends Observable {
	public void addListener(Observer o){
		addObserver(o);
	}
	public void sendEvent(String cmd){
		setChanged();
		notifyObservers(cmd);
	}
}
