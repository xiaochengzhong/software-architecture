import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;


public class Outputer extends Filter {
	private FileWriter fileWriter;

	public Outputer(TextLinePipe in, TextLinePipe out) {
		super(in, out);
		// TODO Auto-generated constructor stub
	}
	public Outputer(TextLinePipe in,FileWriter fw)
	{
		super(in, null);
		fileWriter=fw;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		try{
			BufferedWriter bw=new BufferedWriter(fileWriter);
			String data="";
			while ((data=inPipe.readLine())!=null) {
				bw.write(data);
				bw.newLine();
			}
			bw.flush();
			bw.close();
			inPipe.closeWriter();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
