import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Inputer extends Filter {

	private FileReader fr;
	public Inputer(TextLinePipe in, TextLinePipe out) {
		super(in, out);
		// TODO Auto-generated constructor stub
	}

	public Inputer(FileReader fr,TextLinePipe out)
	{
		
		super(null, out);
		this.fr=fr;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(fr);
		try{
			while (br.ready()) {
				outPipe.writeLine(br.readLine());
				outPipe.flushWriter();
			}
			br.close();
			outPipe.closeWriter();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
