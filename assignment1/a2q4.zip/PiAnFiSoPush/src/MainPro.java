import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class MainPro {
	public static void main(String[] args){
		String inputFile="input.txt";
		String outputFile="output.txt";
		try{
			FileReader fr = new FileReader(inputFile);
			FileWriter fw = new FileWriter(outputFile);
			TextLinePipe p1 = new TextLinePipe();
			Inputer ip=new Inputer(fr, p1);
			TextLinePipe p2 = new TextLinePipe();
			CircularShifter cs = new CircularShifter(p1, p2);
			TextLinePipe p3 = new TextLinePipe();
			Alphabetizer ab = new Alphabetizer(p2, p3);
			Outputer op = new Outputer(p3, fw);
			ip.start();
			cs.start();
			ab.start();
			op.start();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
