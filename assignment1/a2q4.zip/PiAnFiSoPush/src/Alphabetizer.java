import java.util.ArrayList;
import java.util.Collections;


public class Alphabetizer extends Filter {

	public Alphabetizer(TextLinePipe in, TextLinePipe out) {
		super(in, out);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		String data="";
		ArrayList<String> lines=new ArrayList<String>();
		while((data=inPipe.readLine())!=null)
		{
			lines.add(data);
		}
		Collections.sort(lines);
		for(int i=0;i!=lines.size();i++){
			outPipe.writeLine(lines.get(i));
		}
		outPipe.flushWriter();
		outPipe.closeWriter();
	}
}
