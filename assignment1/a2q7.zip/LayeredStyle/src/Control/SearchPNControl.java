package Control;

import java.util.ArrayList;

import Model.PhoneRecord;

public class SearchPNControl extends abstractControl {

	public ArrayList<PhoneRecord> control(PhoneRecord phoneRecord) {
		// TODO Auto-generated method stub
		return dataManager.searchPN(phoneRecord);
	}

}
