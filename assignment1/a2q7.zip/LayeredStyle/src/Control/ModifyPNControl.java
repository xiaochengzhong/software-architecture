package Control;

import Model.PhoneRecord;

public class ModifyPNControl extends abstractControl {


	public String control(PhoneRecord oldPhoneRecord, PhoneRecord newPhoneRecord) {
		// TODO Auto-generated method stub
		return dataManager.modifyPN(oldPhoneRecord, newPhoneRecord);
	}

}
