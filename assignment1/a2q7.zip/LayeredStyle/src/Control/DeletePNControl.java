package Control;

import Model.PhoneRecord;

public class DeletePNControl extends abstractControl {

	public String control(PhoneRecord phoneRecord) {
		// TODO Auto-generated method stub
		return dataManager.deletePN(phoneRecord);
	}

}
