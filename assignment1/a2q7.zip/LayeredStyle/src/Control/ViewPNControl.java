package Control;

import java.util.ArrayList;

import Model.PhoneRecord;

public class ViewPNControl extends abstractControl {


	public ArrayList<PhoneRecord> control() {
		// TODO Auto-generated method stub
		return dataManager.viewPN();
	}

}
