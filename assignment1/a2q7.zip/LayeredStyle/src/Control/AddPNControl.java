package Control;

import Model.PhoneRecord;

public class AddPNControl extends abstractControl {
	
	public AddPNControl(){
		super();
	}
	public String control(PhoneRecord phoneRecord) {
		// TODO Auto-generated method stub
		return dataManager.addPN(phoneRecord);
	}

}
