package Control;

import Model.DataManager;


public abstract class abstractControl {
	protected DataManager dataManager;
	
	public abstractControl(){
		dataManager=new DataManager();
	}

}
