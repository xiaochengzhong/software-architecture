package Model;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class DataManager {
	private final String fileName="data.txt";
	private String message;
	
	public DataManager(){
		message="";
	}
	
	public String addPN(PhoneRecord phoneRecord){
		boolean exist=existRecord(phoneRecord);
		if(exist){
			message="The record is exist.";
		}else{
			BufferedWriter bw=null;
			String record=phoneRecord.getFirstName()+","+phoneRecord.getLastName()+","+phoneRecord.getPhoneNumber()+","+phoneRecord.getDescription();
			try {
				bw=new BufferedWriter(new FileWriter(fileName, true));
				bw.write(record);
				bw.newLine();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			message="add successed.";
		}
		return message;
	}
	public String modifyPN(PhoneRecord oldPhoneRecord, PhoneRecord newPhoneRecord){
		boolean exist=existRecord(oldPhoneRecord);
		if(!exist){
			message="The record is not exist.";
		}else{
			StringBuffer AllRecord=new StringBuffer(4096);;
			String line="";
			String record=oldPhoneRecord.getFirstName()+","+oldPhoneRecord.getLastName()+","+oldPhoneRecord.getPhoneNumber();
			try {
				BufferedReader bf=new BufferedReader(new FileReader(fileName));
				while(line!=null){
					line=bf.readLine();
					if(line!=null){
						if(!line.contains(record)){
							AllRecord.append(line).append("\r\n");
						}else{
							oldPhoneRecord=createRecord(line);
							newPhoneRecord.setDescription(oldPhoneRecord.getDescription());
							String newRecord=newPhoneRecord.getFirstName()+","+newPhoneRecord.getLastName()+","+newPhoneRecord.getPhoneNumber()+","+newPhoneRecord.getDescription();
							AllRecord.append(newRecord).append("\r\n");
						}
					}
				}
				bf.close();
				BufferedWriter bw=new BufferedWriter(new FileWriter(fileName));
				bw.write(AllRecord.toString());
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			message="modify successed.";
		}
		return message;
	}
	public ArrayList<PhoneRecord> searchPN(PhoneRecord phoneRecord){
		ArrayList<PhoneRecord> phoneRecords=new ArrayList<PhoneRecord>();
		String line="";
		String record=phoneRecord.getFirstName()+","+phoneRecord.getLastName();
		try{
			BufferedReader bf=new BufferedReader(new FileReader(fileName));
			while(line!=null){
				line=bf.readLine();
				if(line!=null){
					if(line.contains(record)){
						PhoneRecord pr=createRecord(line);
						phoneRecords.add(pr);
					}
				}
			}
			bf.close();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return phoneRecords;
	}

	public ArrayList<PhoneRecord> viewPN(){
		ArrayList<PhoneRecord> phoneRecords=new ArrayList<PhoneRecord>();
		String line="";
		try{
			BufferedReader bf=new BufferedReader(new FileReader(fileName));
			while(line!=null){
				line=bf.readLine();
				if(line!=null){
					PhoneRecord pr=createRecord(line);
					phoneRecords.add(pr);
				}
			}
			bf.close();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return phoneRecords;
	}
	public String deletePN(PhoneRecord phoneRecord){
		boolean exist=existRecord(phoneRecord);
		if(!exist){
			message="The record is not exist.";
		}else{
			StringBuffer AllRecord=new StringBuffer(4096);
			String line="";
			String record=phoneRecord.getFirstName()+","+phoneRecord.getLastName()+","+phoneRecord.getPhoneNumber();
			try {
				BufferedReader bf=new BufferedReader(new FileReader(fileName));
				while(line!=null){
					line=bf.readLine();
					if(line!=null){
						if(!line.contains(record)){
							AllRecord.append(line).append("\r\n");
						}
					}
				}
				bf.close();
				BufferedWriter bw=new BufferedWriter(new FileWriter(fileName));
				bw.write(AllRecord.toString());
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			message="delete successed.";
		}
		return message;
	}
	private boolean existRecord(PhoneRecord phoneRecord){
		boolean result=false;
		String line="";
		String record=phoneRecord.getFirstName()+","+phoneRecord.getLastName()+","+phoneRecord.getPhoneNumber();
		try {
			BufferedReader bf=new BufferedReader(new FileReader(fileName));
			while(line!=null){
				try {
					line=bf.readLine();
					if(line!=null){
						if(line.contains(record)){
							result=true;
							break;
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			bf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	private PhoneRecord createRecord(String line) {
		// TODO Auto-generated method stub
		PhoneRecord pr=new PhoneRecord();
		StringTokenizer tokener = new StringTokenizer(line, ",");
		String token = new String();
		ArrayList<String> tokens = new ArrayList<String>();
        int count = tokener.countTokens();
        for (int j = 0; j < count; j++) {
            token = tokener.nextToken();
            tokens.add(token);
        }
        pr.setFirstName(tokens.get(0));
        pr.setLastName(tokens.get(1));
        pr.setPhoneNumber(Integer.parseInt(tokens.get(2)));
        pr.setDescription(tokens.get(3));
		return pr;
	}
}
