import UI.MenuUI;


public class MainPro {
	public static void main(String[] args){
		MenuUI mu=new MenuUI();
		mu.display();
	}
}
