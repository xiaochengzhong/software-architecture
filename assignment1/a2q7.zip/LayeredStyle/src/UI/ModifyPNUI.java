package UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import Control.ModifyPNControl;
import Model.PhoneRecord;

public class ModifyPNUI extends abstractUI {
	private PhoneRecord OldPhoneRecord;
	private PhoneRecord NewPhoneRecord;
	private ModifyPNControl modifyPNControl;

	public ModifyPNUI(){
		super();
		OldPhoneRecord=new PhoneRecord();
		NewPhoneRecord=new PhoneRecord();
		modifyPNControl=new ModifyPNControl();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("please input your first name: ");
			OldPhoneRecord.setFirstName(br.readLine());
			NewPhoneRecord.setFirstName(OldPhoneRecord.getFirstName());
			System.out.print("please input your last name: ");
			OldPhoneRecord.setLastName(br.readLine());
			NewPhoneRecord.setLastName(OldPhoneRecord.getLastName());
			System.out.print("please input your old phone number: ");
			OldPhoneRecord.setPhoneNumber(Integer.parseInt(br.readLine()));
			System.out.print("please input your new phone number: ");
			NewPhoneRecord.setPhoneNumber(Integer.parseInt(br.readLine()));
			String result=modifyPNControl.control(OldPhoneRecord, NewPhoneRecord);
			System.out.println(result);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
