package UI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MenuUI extends abstractUI {
	private boolean loop;
	private AddPNUI addPNUI;
	private ModifyPNUI modifyPNUI;
	private SearchPNUI searchPNUI;
	private ViewPNUI viewPNUI;
	private DeletePNUI deletePNUI;

	public MenuUI(){
		super();
		loop=true;
		addPNUI=new AddPNUI();
		modifyPNUI=new ModifyPNUI();
		searchPNUI=new SearchPNUI();
		viewPNUI=new ViewPNUI();
		deletePNUI=new DeletePNUI();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		while(loop){
			displayMenu();
			try{
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				cmd=Integer.parseInt(br.readLine());
			}catch(IOException e){
				e.printStackTrace();
			}
			switch(cmd){
				case 1:
					addPNUI.display();
					break;
				case 2:
					modifyPNUI.display();
					break;
				case 3:
					searchPNUI.display();
					break;
				case 4:
					viewPNUI.display();
					break;
				case 5:
					deletePNUI.display();
					break;
				case 6:
					loop=false;
					break;
				default:
					System.out.println("Invild commend!");
					break;
			}
		}
	}
	private void displayMenu(){
		System.out.println();
		System.out.println("-------Welcome to your phone book!-------");
		System.out.println("1. Add phone number .");
		System.out.println("2. Modify phone number .");
		System.out.println("3. Search phone number .");
		System.out.println("4. View phone number .");
		System.out.println("5. Delete phone number .");
		System.out.println("6. exit phone book .");
		System.out.println("------------------end!-------------------");
		System.out.println();
	}

}
