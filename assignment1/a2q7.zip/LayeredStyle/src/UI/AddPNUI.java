package UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import Control.AddPNControl;
import Model.PhoneRecord;

public class AddPNUI extends abstractUI {
	private PhoneRecord phoneRecord;
	private AddPNControl addPNControl;

	public AddPNUI(){
		super();
		phoneRecord=new PhoneRecord();
		addPNControl=new AddPNControl();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("please input your first name: ");
			phoneRecord.setFirstName(br.readLine());
			System.out.print("please input your last name: ");
			phoneRecord.setLastName(br.readLine());
			System.out.print("please input your phone number: ");
			phoneRecord.setPhoneNumber(Integer.parseInt(br.readLine()));
			System.out.print("please input the discription: ");
			phoneRecord.setDescription(br.readLine());
			String result=addPNControl.control(phoneRecord);
			System.out.println(result);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
