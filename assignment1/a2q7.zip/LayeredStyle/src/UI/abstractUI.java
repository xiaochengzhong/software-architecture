package UI;


abstract public class abstractUI {
	
	protected int cmd;
	
	public abstractUI(){
		cmd=0;
	}
	abstract public  void display();

}
