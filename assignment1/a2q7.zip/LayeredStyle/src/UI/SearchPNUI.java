package UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import Control.SearchPNControl;
import Model.PhoneRecord;

public class SearchPNUI extends abstractUI {
	private PhoneRecord phoneRecord;
	private ArrayList<PhoneRecord> phoneRecords;
	private SearchPNControl searchPNControl;

	public SearchPNUI(){
		super();
		phoneRecord=new PhoneRecord();
		phoneRecords=new ArrayList<PhoneRecord>();
		searchPNControl=new SearchPNControl();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("please input your first name: ");
			phoneRecord.setFirstName(br.readLine());
			System.out.print("please input your last name: ");
			phoneRecord.setLastName(br.readLine());
			phoneRecords=searchPNControl.control(phoneRecord);
			for(int i=0; i!=phoneRecords.size(); i++){
				System.out.println(phoneRecords.get(i).getFirstName() + ", " + phoneRecords.get(i).getLastName() + ", " + 
						phoneRecords.get(i).getPhoneNumber() + ", " + phoneRecords.get(i).getDescription());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
