package UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import Control.DeletePNControl;
import Model.PhoneRecord;

public class DeletePNUI extends abstractUI {
	private PhoneRecord phoneRecord;
	private DeletePNControl deletePNControl;

	public DeletePNUI(){
		super();
		phoneRecord=new PhoneRecord();
		deletePNControl=new DeletePNControl();
	}
	@Override
	public void display() {
		// TODO Auto-generated method stub

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("please input your first name: ");
			phoneRecord.setFirstName(br.readLine());
			System.out.print("please input your last name: ");
			phoneRecord.setLastName(br.readLine());
			System.out.print("please input your phone number: ");
			phoneRecord.setPhoneNumber(Integer.parseInt(br.readLine()));
			String result=deletePNControl.control(phoneRecord);
			System.out.println(result);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
