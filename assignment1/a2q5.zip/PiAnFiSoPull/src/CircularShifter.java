import java.util.ArrayList;
import java.util.StringTokenizer;


public class CircularShifter extends Filter {

	public CircularShifter(TextLinePipe in, TextLinePipe out, TextLinePipe deIn, TextLinePipe deOut) {
		super(in, out, deIn, deOut);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		String readline="";
		int shiftedLineIndexes=0;
		while ((readline = inPipe.readLine()) != null) {
			StringTokenizer tokener = new StringTokenizer(readline);
			String token = new String();
			ArrayList<String> tokens = new ArrayList<String>();
		    int count = tokener.countTokens();
		    for (int j = 0; j < count; j++) {
		        token = tokener.nextToken();
		        tokens.add(token);
		    }
		    for (int i = 0; i < count; i++) {
		    	shiftedLineIndexes=i;
		        StringBuffer linebuffer = new StringBuffer();
		        for (int j = 0; j < count; j++) {
		            if (shiftedLineIndexes >= count)
		            	shiftedLineIndexes = 0;
		                linebuffer.append ( tokens.get(shiftedLineIndexes));
		                linebuffer.append (" ");
		                shiftedLineIndexes++;
		        }
		        outPipe.writeLine(linebuffer.toString());
		    }
		}
		outPipe.flushWriter();
		outPipe.closeWriter();
		inPipe.closeWriter();
	}

	@Override
	public void flow() {
		// TODO Auto-generated method stub
		while(deInPipe.readLine()!=null){
			deOutPipe.writeLine("fuck you!!!!");
			deOutPipe.flushWriter();
			execute();
		}
		deOutPipe.closeWriter();
	}

}
