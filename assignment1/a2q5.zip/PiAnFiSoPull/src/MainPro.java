import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class MainPro {
	public static void main(String[] args){
		String inputFile="input.txt";
		String outputFile="output.txt";
		try{
			FileReader fr = new FileReader(inputFile);
			FileWriter fw = new FileWriter(outputFile);
			TextLinePipe p1 = new TextLinePipe();
			TextLinePipe dp1 = new TextLinePipe();
			Inputer ip=new Inputer(fr, p1, dp1, null);
			TextLinePipe p2 = new TextLinePipe();
			TextLinePipe dp2 = new TextLinePipe();
			CircularShifter cs = new CircularShifter(p1, p2,dp2,dp1);
			TextLinePipe p3 = new TextLinePipe();
			TextLinePipe dp3 = new TextLinePipe();
			Alphabetizer ab = new Alphabetizer(p2, p3,dp3,dp2);
			Outputer op = new Outputer(p3, fw,null,dp3);
			op.start();
			ab.start();
			cs.start();
			ip.start();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
