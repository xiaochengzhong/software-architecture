import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Inputer extends Filter {

	private FileReader fr;
	public Inputer(TextLinePipe in, TextLinePipe out, TextLinePipe deIn, TextLinePipe deOut) {
		super(in, out, deIn, deOut);
		// TODO Auto-generated constructor stub
	}

	public Inputer(FileReader fr,TextLinePipe out, TextLinePipe deIn, TextLinePipe deOut)
	{
		super(null, out, deIn, null);
		this.fr=fr;
	}
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		BufferedReader br=new BufferedReader(fr);
		try{
			while (br.ready()) {
				outPipe.writeLine(br.readLine());
				outPipe.flushWriter();
			}
			br.close();
			outPipe.closeWriter();
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	@Override
	public void flow() {
		// TODO Auto-generated method stub
		while(deInPipe.readLine()!=null){
			execute();
		}
		deInPipe.closeReader();
	}

}
