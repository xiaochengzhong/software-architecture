import java.util.Collections;


public class Alphabetizer {
	public void execute(){
		Collections.sort(Blackboard.TextLines);
	}

}
