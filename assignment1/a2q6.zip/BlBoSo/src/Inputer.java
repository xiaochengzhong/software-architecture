
public class Inputer {

	public void execute(String input){
		Blackboard.textLine=input;
	}

}
