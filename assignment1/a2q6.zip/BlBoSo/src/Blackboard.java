import java.util.ArrayList;


public class Blackboard {
	public static String textLine;
	public static String shifted_textLine;
	public static ArrayList<String> TextLines;
	public Blackboard(){
		textLine="";
		shifted_textLine="";
		TextLines=new ArrayList<String>();
	}

}
