import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Control {
	public static void main(String[] args){
		String inputFile="input.txt";
		String line="";
		new Blackboard();
		Inputer ip=new Inputer();
		CircularShifter cs = new CircularShifter();
		Alphabetizer ab = new Alphabetizer();
		Outputer op = new Outputer();
		try {
			BufferedReader bf=new BufferedReader(new FileReader(inputFile));
			while(line!=null){
				try {
					line=bf.readLine();
					if(line!=null){
						ip.execute(line);
						cs.execute();
						ab.execute();
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			bf.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		op.execute();
	}

}
